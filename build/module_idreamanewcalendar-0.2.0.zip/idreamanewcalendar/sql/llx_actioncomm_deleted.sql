-- Copyright (C) 2019-2025  Frédéric FRANCE <frederic.france@free.fr>
--
-- This program is free software; you can redistribute it and/or modify
-- it under the terms of the GNU General Public License as published by
-- the Free Software Foundation; either version 3 of the License, or
-- (at your option) any later version.
--
-- This program is distributed in the hope that it will be useful,
-- but WITHOUT ANY WARRANTY; without even the implied warranty of
-- MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
-- GNU General Public License for more details.
--
-- You should have received a copy of the GNU General Public License
-- along with this program. If not, see http://www.gnu.org/licenses/.


CREATE TABLE llx_actioncomm_deleted(
    rowid INTEGER AUTO_INCREMENT PRIMARY KEY,
    tms TIMESTAMP  on update CURRENT_TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    fk_actioncomm INTEGER NOT NULL
)ENGINE=innodb;
