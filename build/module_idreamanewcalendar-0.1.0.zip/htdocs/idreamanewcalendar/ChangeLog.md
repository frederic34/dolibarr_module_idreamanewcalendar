
## Unreleased (2025-11-11)

#### :rocket: Enhancement
* [#1](https://github.com/frederic34/dolibarr_module_idreamanewcalendar/pull/1) add translation ([@frederic34](https://github.com/frederic34))

#### :bug: Bug Fix
* [#3](https://github.com/frederic34/dolibarr_module_idreamanewcalendar/pull/3) rename trigger ([@frederic34](https://github.com/frederic34))

#### Committers: 1
- Frédéric FRANCE ([@frederic34](https://github.com/frederic34))
